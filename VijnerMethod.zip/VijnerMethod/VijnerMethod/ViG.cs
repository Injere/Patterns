﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VijnerMethod
{
    class ViG
    {
        static char[] characters = new char[] {
            //'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И',
            //                                        'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С',
            //                                        'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ь', 'Ы', 'Ъ',
            //                                        'Э', 'Ю', 'Я', ' ', '1', '2', '3', '4', '5', '6', '7',
            //                                        '8', '9', '0', ' ',
            'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и',
                                                'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с',
                                                'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ь', 'ы', 'ъ',
                                                'э', 'ю', 'я','.' ,',' ,'!'};

        int N = characters.Length;
        public string Code ( string Sl,string KeYT)
        {

            //Sl = Sl.ToUpper();
            //KeYT = KeYT.ToUpper();

                string result = "";
            int c =-1;
                int keyword_index = 0;

                foreach (char symbol in Sl)
                {
                 c = (Array.IndexOf(characters, symbol));
               
                int p = Array.IndexOf(characters, KeYT[keyword_index])%characters.Length;
                c += p;


                //int c = (Array.IndexOf(characters, symbol) +
                //    Array.IndexOf(characters, KeYT[keyword_index])) % N;
                if (c > 36)
                {
                    int h = c - 36;
                    c = 0;
                    c = c + h;
                }

                result += characters[c];

                    keyword_index++;

                    if ((keyword_index + 1) > KeYT.Length)
                        keyword_index = 0;
                }

                return result;
            
        }
        public string DeCode(string Sl, string KeYT)
        {

            //Sl = Sl.ToUpper();
            //    KeYT = KeYT.ToUpper();

                string result = "";

                int keyword_index = 0;
            int c = 0;

                foreach (char symbol in Sl)
                {
                c = (Array.IndexOf(characters, symbol));
                int p = Array.IndexOf(characters, KeYT[keyword_index])%characters.Length;
                c -= p;
                //int p = (Array.IndexOf(characters, symbol) + N -
                //        Array.IndexOf(characters, KeYT[keyword_index])) % N;

                    result += characters[c];

                    keyword_index++;

                    if ((keyword_index + 1) > KeYT.Length)
                        keyword_index = 0;
                }

                return result;
           
        }
    }
}
