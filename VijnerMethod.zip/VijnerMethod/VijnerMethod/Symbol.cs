﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VijnerMethod
{
    
        public class Symbol
        {
            public string Text { get; set; }
            public int Count { get; set; }
            public double Probability { get; set; }
            public string Code { get; set; }

        }
   
}
