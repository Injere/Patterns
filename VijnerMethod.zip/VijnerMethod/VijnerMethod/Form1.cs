﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VijnerMethod
{
    public partial class Vijner : Form
    {

        public Vijner()
        {
            InitializeComponent();
            GB();


        }
        Form2 form2 = new Form2();

        /// <summary>
        /// Получает строку и возвращает массив, соответствующий строке в закодированном виде
        /// </summary>
        /// <param name="str">Строка(буквенная)</param>
        /// <returns></returns>




        /// <summary>
        /// Возвращает итоговый закодированный массив
        /// </summary>
        /// <param name="str">Строка(интовый массив)</param>
        /// <param name="key">Ключ(интовый массив)</param>
        /// <returns></returns>


        /// <summary>
        /// Возвращает итоговый декодированный массив
        /// </summary>
        /// <param name="str">Закодированная строка</param>
        /// <param name="key">Закодированный ключ</param>
        /// <returns></returns>

       



        private void BResult_Click(object sender, EventArgs e)
        {
            if (ViGEN.Checked == true)
            {
                string SLovo = TBInput.Text;
                string KeyT = TBKey.Text;
                ViG viG = new ViG();
                TBOutput.Text = viG.Code(SLovo, KeyT);
            }

            if(SH.Checked==true)
            {
                ShennonFano shennonFano = new ShennonFano();
                BResult.Click += (s, m) =>
                {
                    var result = ShennonFano.Encode(TBInput.Text);
                   


                    form2.txtTable.Text = JsonConvert.SerializeObject(result.Item2);//кодирование
                    TBOutput.Text = result.Item1;
                };
            }



        }

        private void BDec_Click(object sender, EventArgs e)
        {
            if (ViGEN.Checked == true)
            {
                string SLovo = TBInput.Text;
                string KeyT = TBKey.Text;
                ViG viG = new ViG();
                TBOutput.Text = viG.DeCode(SLovo, KeyT);
            }

            if(SH.Checked==true)
            {
                BDec.Click += (s, m) =>
                {
                    if (string.IsNullOrEmpty(form2.txtTable.Text)) { MessageBox.Show("Отсутствует таблица кодировки."); return; }
                    if (TBInput.Text.Any(x => x != '0' && x != '1')) { MessageBox.Show("Данные не в бинарном виде."); return; }

                    var symbols = new List<Symbol>();

                    try
                    {
                        symbols = JsonConvert.DeserializeObject<List<Symbol>>(form2.txtTable.Text);
                        
                    }
                    catch
                    {
                        MessageBox.Show("Неверная таблица кодировки."); return;
                    }


                    TBOutput.Text = ShennonFano.Decode(TBInput.Text, symbols);
                };
            }

        }

        private void TBOutput_TextChanged(object sender, EventArgs e)
        {

        }

        private void RadioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ViGEN_CheckedChanged(object sender, EventArgs e)
        {
            groupBox1.Enabled = true;//недоступность
            groupBox1.Visible = true;//скрытие поля ввода
          
        }

        public void GB()
        {
            groupBox1.Enabled = false;//недоступность
            groupBox1.Visible = false;//скрытие поля ввода
        }
        private void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            GB();
            form2.Show();



        }

        private void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            GB();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            form2.Show();
        }
    }
}
