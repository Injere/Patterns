﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace MiniPaint
{
    public partial class Form2 : Form
    {
        bool flags = true;
        public string str { get; set; }
        public List<Uniforms> unis { get; set; }

        public Form2()
        {
            InitializeComponent();
            backgroundWorker1.WorkerReportsProgress = true;
            backgroundWorker1.WorkerSupportsCancellation = true;
        }

        private void SaveOrOpen()
        {
            if (this.Text == "Сохранение")
            {
                using (StreamWriter sw = new StreamWriter(str, true, System.Text.Encoding.Default))
                {
                    int max = unis.Count();
                    int min = 0;
                    foreach (Uniforms uni in unis)
                    {
                        sw.Write(uni.pens.Name + " ");
                        sw.Write(uni.str + " ");
                        sw.Write(uni.X1 + " ");
                        sw.Write(uni.Y1 + " ");
                        sw.Write(uni.X2 + " ");
                        sw.WriteLine(uni.Y2);

                        backgroundWorker1.ReportProgress(min * 100 / max);
                        min++;

                        if (!flags)
                            break;
                        Thread.Sleep(500);
                    }
                }
            }
            if (this.Text == "Открытие")
            {
                using (StreamReader sr = new StreamReader(str, System.Text.Encoding.Default))
                {
                    string rst;
                    int max = System.IO.File.ReadAllLines(str).Length;
                    int min = 0;

                    while ((rst = sr.ReadLine()) != null)
                    {
                        string[] fig = rst.Split(' ');
                        unis.Add(new Uniforms
                        {
                            pens = Color.FromName(fig[0]),
                            str = fig[1],
                            X1 = int.Parse(fig[2]),
                            Y1 = int.Parse(fig[3]),
                            X2 = int.Parse(fig[4]),
                            Y2 = int.Parse(fig[5])

                        });

                        backgroundWorker1.ReportProgress(min * 100 / max);
                        min++;

                        if (!flags)
                            break;

                        Thread.Sleep(500);
                    }
                }
            }
            label2.Text = this.Text + " завершено";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            flags = false;
            label2.Text = this.Text + " прекращено";
            backgroundWorker1.CancelAsync();
            backgroundWorker1.DoWork -= backgroundWorker1_DoWork;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            backgroundWorker1.Dispose();
            this.Close();
        }

        private void Form2_Shown(object sender, EventArgs e)
        {
            if (this.Text == "Сохранение")
                label2.Text = "Идёт сохранение файла";
            if (this.Text == "Открытие")
                label2.Text = "Идёт открытие файла";
            backgroundWorker1.RunWorkerAsync();
            backgroundWorker1.DoWork += backgroundWorker1_DoWork;
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.Text == "Сохранение")
            {
                if (progressBar1.Value != progressBar1.Maximum || !flags)
                    File.Delete(str);
            }
            if (this.Text == "Открытие")
            {
                if (progressBar1.Value != progressBar1.Maximum || !flags)
                    unis.Clear();
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            SaveOrOpen();
            backgroundWorker1.DoWork -= backgroundWorker1_DoWork;
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            button2.Visible = true;
        }
    }
}
