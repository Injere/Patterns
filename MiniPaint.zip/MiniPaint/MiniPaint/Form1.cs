﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiniPaint
{
    public partial class Form1 : Form
    {
        Color CurrentColor = Color.Black;
        bool isPresset;
        Point CurrentPoint;//x2y2
        Point PrevPoint;//x1y1
        Graphics graph;
        Pen p;
        string figures = "Кисть";
        int x1, x2, y1, y2, width, heigth, x, y;
        List<Uniforms> uniforms = new List<Uniforms>();
        Form2 form2 = new Form2();

        private void button6_Click(object sender, EventArgs e)
        {
            //очищаем холст
            graph.Clear(Color.White);
            uniforms.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            figures = ((Button)sender).Text;//забираем текст кнопки
        }

        private void кистьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            figures = ((ToolStripMenuItem)sender).Text;//забираем текст меню, как у кнопки
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            pictureBox3.BackColor = CurrentColor;
            p = new Pen(CurrentColor);
            graph = panel1.CreateGraphics();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult D = colorDialog1.ShowDialog();//вызываем окно выбора цвета
            if (System.Windows.Forms.DialogResult.OK == D) //если была нажата кнопка "ОК"
            {
                CurrentColor = colorDialog1.Color; //забираем выбранный цвет
                pictureBox3.BackColor = CurrentColor;//рисуем задний фон полученным цветом в маленькой картинке
                p = new Pen(CurrentColor);//изменяем цвет линий
            }
        }

        public void lins(int x1, int y1, int x2, int y2)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
        }

        private void Otris()
        {
            foreach (Uniforms uni in uniforms)
            {
                switch (uni.str)
                {
                    case "Кисть":
                        {
                            brushes(uni.X1, uni.Y1, uni.X2, uni.Y2);
                            graph.DrawLine(new Pen(uni.pens), x1, y1, x2, y2);
                        }
                        break;
                    case "Круг":
                        {
                            Circls(uni.X1, uni.Y1, uni.X2, uni.Y2);
                            graph.DrawEllipse(new Pen(uni.pens), x, y, width, heigth);
                        }
                        break;
                    case "Квадрат":
                        {
                            squars(uni.X1, uni.Y1, uni.X2, uni.Y2);
                            graph.DrawRectangle(new Pen(uni.pens), x, y, width, heigth);
                        }
                        break;
                    case "Линия":
                        {
                            lins(uni.X1, uni.Y1, uni.X2, uni.Y2);
                            graph.DrawLine(new Pen(uni.pens), x1, y1, x2, y2);
                        }
                        break;
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Otris();
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isPresset = false;//запрещаем рисовать когда кнопка мыши не зажата
            uniforms.Add(new Uniforms
            {
                X1 = PrevPoint.X,
                Y1 = PrevPoint.Y,
                X2 = CurrentPoint.X,
                Y2 = CurrentPoint.Y,
                pens = CurrentColor,
                str = figures
            });
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            //кнопка мыши зажата
            if (isPresset == true)
            {
                if (figures == "Кисть")
                {
                    PrevPoint = CurrentPoint;//записываем координаты, с которой была зажата кнопка мыши
                }

                Drow(new Pen(Color.White));

                CurrentPoint = e.Location;//записываем новые координаты

                Drow();

                if (figures == "Кисть")
                {
                    uniforms.Add(new Uniforms
                    {
                        X1 = PrevPoint.X,
                        Y1 = PrevPoint.Y,
                        X2 = CurrentPoint.X,
                        Y2 = CurrentPoint.Y,
                        pens = CurrentColor,
                        str = figures
                    });
                }
                Otris();
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            isPresset = true;//если зажали кнопку мыши, то рисуем
            if (figures == "Кисть")
                CurrentPoint = e.Location;
            else
                PrevPoint = e.Location;//записывает координаты х,у на котором была зажата кнопка мыши
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            DialogResult D = colorDialog1.ShowDialog();//вызываем окно выбора цвета
            if (System.Windows.Forms.DialogResult.OK == D) //если была нажата кнопка "ОК"
            {
                CurrentColor = colorDialog1.Color; //забираем выбранный цвет
                pictureBox3.BackColor = CurrentColor;//рисуем задний фон полученным цветом в маленькой картинке
                p = new Pen(CurrentColor);//изменяем цвет линий
            }
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = ".xml | *.xml";
            saveFileDialog1.ShowDialog();
            if (saveFileDialog1.FileName != "")
            {
                form2.Text = "Сохранение";
                form2.str = saveFileDialog1.FileName;
                form2.unis = uniforms;
                form2.ShowDialog();
            }
            //using (StreamWriter sw = new StreamWriter(saveFileDialog1.FileName, true,System.Text.Encoding.Default))
            //{
            //    foreach(Uniforms uni in uniforms)
            //    {
            //        sw.Write(uni.pens.Name + " ");
            //        sw.Write(uni.str + " ");
            //        sw.Write(uni.X1 + " ");
            //        sw.Write(uni.Y1 + " ");
            //        sw.Write(uni.X2 + " ");
            //        sw.WriteLine(uni.Y2);
            //    }
            //}
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            graph.Dispose();
            this.Close();
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = ".xml | *.xml";
            openFileDialog1.ShowDialog();
            form2.Text = "Открытие";
            form2.str = openFileDialog1.FileName;
            form2.unis = uniforms;
            form2.ShowDialog();
            uniforms = form2.unis;
            Otris();

            //using (StreamReader sr = new StreamReader(openFileDialog1.FileName, System.Text.Encoding.Default))
            //{
            //    string rst;
            //    while((rst = sr.ReadLine())!=null)
            //    {
            //        string[] fig = rst.Split(' ');
            //        uniforms.Add(new Uniforms
            //        {
            //            pens = Color.FromName(fig[0]),
            //            str = fig[1],
            //            X1 = int.Parse(fig[2]),
            //            Y1 = int.Parse(fig[3]),
            //            X2 = int.Parse(fig[4]),
            //            Y2 = int.Parse(fig[5])
            //        });
            //    }
            //}
        }

        public void Circls(int x1, int y1, int x2, int y2)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            x = x1;
            y = y1;
            if (x > x2) x = x2;
            if (y > y2) y = y2;
            width = Math.Abs(x2 - x1);
            heigth = Math.Abs(y2 - y1);
        }

        public void brushes(int x1, int y1, int x2, int y2)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
        }

        public void squars(int x1, int y1, int x2, int y2)
        {
            x = x1;
            y = y1;
            if (x > x2) x = x2;
            if (y > y2) y = y2;
            width = Math.Abs(x2 - x1);
            heigth = Math.Abs(y2 - y1);
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Drow()
        {
            switch (figures)
            {
                case "Кисть":
                    {
                        brushes(PrevPoint.X, PrevPoint.Y, CurrentPoint.X, CurrentPoint.Y);
                        graph.DrawLine(p, x1, y1, x2, y2);
                    }
                    break;
                case "Круг":
                    {
                        Circls(PrevPoint.X, PrevPoint.Y, CurrentPoint.X, CurrentPoint.Y);
                        graph.DrawEllipse(p, x, y, width, heigth);
                    }
                    break;
                case "Квадрат":
                    {
                        squars(PrevPoint.X, PrevPoint.Y, CurrentPoint.X, CurrentPoint.Y);
                        graph.DrawRectangle(p, x, y, width, heigth);
                    }
                    break;
                case "Линия":
                    {
                        lins(PrevPoint.X, PrevPoint.Y, CurrentPoint.X, CurrentPoint.Y);
                        graph.DrawLine(p, x1, y1, x2, y2);
                    }
                    break;
            }
        }
        private void Drow(Pen pens)
        {
            switch (figures)
            {
                case "Круг":
                    {
                        Circls(PrevPoint.X, PrevPoint.Y, CurrentPoint.X, CurrentPoint.Y);
                        graph.DrawEllipse(pens, x, y, width, heigth);
                    }
                    break;
                case "Квадрат":
                    {
                        squars(PrevPoint.X, PrevPoint.Y, CurrentPoint.X, CurrentPoint.Y);
                        graph.DrawRectangle(pens, x, y, width, heigth);
                    }
                    break;
                case "Линия":
                    {
                        lins(PrevPoint.X, PrevPoint.Y, CurrentPoint.X, CurrentPoint.Y);
                        graph.DrawLine(pens, x1, y1, x2, y2);
                    }
                    break;
            }
        }

        //private void Drow(string svk, Point x1y1, Point x2y2, Pen pn )
        //{
        //    switch (svk)
        //    {
        //        case "Кисть":
        //            {
        //                brushes(x1y1.X, x1y1.Y, x2y2.X, x2y2.Y);
        //                graph.DrawLine(pn, x1, y1, x2, y2);
        //            }
        //            break;
        //        case "Круг":
        //            {
        //                Circls(x1y1.X, x1y1.Y, x2y2.X, x2y2.Y);
        //                graph.DrawEllipse(pn, x, y, width, heigth);
        //            }
        //            break;
        //        case "Квадрат":
        //            {
        //                squars(x1y1.X, x1y1.Y, x2y2.X, x2y2.Y);
        //                graph.DrawRectangle(pn, x, y, width, heigth);
        //            }
        //            break;
        //        case "Линия":
        //            {
        //                lins(x1y1.X, x1y1.Y, x2y2.X, x2y2.Y);
        //                graph.DrawLine(pn, x1, y1, x2, y2);
        //            }
        //            break;
        //    }
        //}
    }
}
