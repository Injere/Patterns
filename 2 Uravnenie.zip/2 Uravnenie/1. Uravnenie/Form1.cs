﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1.Uravnenie
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// коэффициент уравнения
        /// </summary>
        double a, b, c; 
        /// <summary>
        /// дескреминант
        /// </summary>
        double d;
        /// <summary>
        /// корень уравнения
        /// </summary>
        double x1, x2;

        /// <summary>
        /// проверка корректности ввода
        /// </summary>
        bool error;

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// решение уравнения
        /// </summary>
        private void solve()
        {
            if (a != 0 ) // ax^2 + bx + c = 0
            {
                d = b*b - 4 * a * c;

                if (d > 0)
                {
                    x1 = (-b + Math.Sqrt(d)) / (2 * a);
                    x2 = (-b - Math.Sqrt(d)) / (2 * a);
                    lb_Answer.Text = "x1 = " + x1 + "\nx2 = " + x2;
                }

                if (d == 0)
                {
                    x1 = - b / (2 * a);
                    lb_Answer.Text = "x = " + x1;
                }

                if (d < 0)
                    lb_Answer.Text = "Уравнение не имеет решения";
            }

            if (a == 0 && b != 0) //bx + c = 0
            {
                x1 = -c / b;
                lb_Answer.Text = "x = " + x1;
            }

            if (a == 0 && b == 0) //с = 0
                lb_Answer.Text = "Уравнение не имеет решения";

            if (a == 0 && b == 0 && c == 0) 
                lb_Answer.Text = "x - любое число";

        }

        /// <summary>
        /// проверка правильности ввода
        /// </summary>
        private void Btn_Find_Click(object sender, EventArgs e)
        {
            error = false;

            // ввод переменных и проверка на корректность
            try
            {
                errorProvider.SetError(tB_VvodB, "");
                b = double.Parse(tB_VvodB.Text);
            }
            catch { errorProvider.SetError(tB_VvodB, "Неправильное значение!"); error = true; }

            try
            {
                errorProvider.SetError(tB_VvodC, "");
                c = double.Parse(tB_VvodC.Text);
            }
            catch { errorProvider.SetError(tB_VvodC, "Неправильное значение!"); error = true; }

            try
            {
                    errorProvider.SetError(tB_VvodA, "");
                    a = double.Parse(tB_VvodA.Text);
            }
            catch { errorProvider.SetError(tB_VvodA, "Неправильное значение!"); error = true; }

            if (error) return;
            else solve();

        }

        /// <summary>
        /// очистка полей для записи коэффициентов
        /// </summary>
        private void btnClearn_Click(object sender, EventArgs e)
        {
            tB_VvodA.Text = null;
            tB_VvodB.Text = null;
            tB_VvodC.Text = null;
            lb_Answer.Text = null;
        }        
    }
}
