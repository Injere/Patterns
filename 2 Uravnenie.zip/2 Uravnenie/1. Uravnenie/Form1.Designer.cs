﻿namespace _1.Uravnenie
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tB_VvodA = new System.Windows.Forms.TextBox();
            this.tB_VvodB = new System.Windows.Forms.TextBox();
            this.tB_VvodC = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Btn_Find = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lb_Answer = new System.Windows.Forms.Label();
            this.btnClearn = new System.Windows.Forms.Button();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(130, 117);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "x^2 + ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(254, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "x + ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(359, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 27);
            this.label3.TabIndex = 2;
            this.label3.Text = "= 0";
            // 
            // tB_VvodA
            // 
            this.tB_VvodA.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tB_VvodA.Location = new System.Drawing.Point(71, 114);
            this.tB_VvodA.Name = "tB_VvodA";
            this.tB_VvodA.Size = new System.Drawing.Size(56, 35);
            this.tB_VvodA.TabIndex = 3;
            this.tB_VvodA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            this.tB_VvodA.TextChanged += new System.EventHandler(this.tB_VvodA_TextChanged);
            // 
            // tB_VvodB
            // 
            this.tB_VvodB.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tB_VvodB.Location = new System.Drawing.Point(194, 114);
            this.tB_VvodB.Name = "tB_VvodB";
            this.tB_VvodB.Size = new System.Drawing.Size(57, 35);
            this.tB_VvodB.TabIndex = 4;
            this.tB_VvodB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
           // this.tB_VvodB.TextChanged += new System.EventHandler(this.tB_VvodB_TextChanged);
            // 
            // tB_VvodC
            // 
            this.tB_VvodC.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tB_VvodC.Location = new System.Drawing.Point(297, 114);
            this.tB_VvodC.Name = "tB_VvodC";
            this.tB_VvodC.Size = new System.Drawing.Size(57, 35);
            this.tB_VvodC.TabIndex = 5;
            this.tB_VvodC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
          //  this.tB_VvodC.TextChanged += new System.EventHandler(this.tB_VvodC_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(89, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(316, 23);
            this.label4.TabIndex = 6;
            this.label4.Text = "Введите коэффициенты уравнения";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Btn_Find
            // 
            this.Btn_Find.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_Find.Location = new System.Drawing.Point(118, 180);
            this.Btn_Find.Name = "Btn_Find";
            this.Btn_Find.Size = new System.Drawing.Size(85, 34);
            this.Btn_Find.TabIndex = 7;
            this.Btn_Find.Text = "Найти";
            this.Btn_Find.UseVisualStyleBackColor = true;
            this.Btn_Find.Click += new System.EventHandler(this.Btn_Find_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(30, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 23);
            this.label5.TabIndex = 8;
            this.label5.Text = "Ответ:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Answer
            // 
            this.lb_Answer.AutoSize = true;
            this.lb_Answer.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_Answer.Location = new System.Drawing.Point(113, 241);
            this.lb_Answer.Name = "lb_Answer";
            this.lb_Answer.Size = new System.Drawing.Size(0, 27);
            this.lb_Answer.TabIndex = 9;
            // 
            // btnClearn
            // 
            this.btnClearn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnClearn.Location = new System.Drawing.Point(232, 180);
            this.btnClearn.Name = "btnClearn";
            this.btnClearn.Size = new System.Drawing.Size(116, 34);
            this.btnClearn.TabIndex = 10;
            this.btnClearn.Text = "Очистить";
            this.btnClearn.UseVisualStyleBackColor = true;
            this.btnClearn.Click += new System.EventHandler(this.btnClearn_Click);
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 334);
            this.Controls.Add(this.btnClearn);
            this.Controls.Add(this.lb_Answer);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Btn_Find);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tB_VvodC);
            this.Controls.Add(this.tB_VvodB);
            this.Controls.Add(this.tB_VvodA);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Решение уравнения";
//            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tB_VvodA;
        private System.Windows.Forms.TextBox tB_VvodB;
        private System.Windows.Forms.TextBox tB_VvodC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Btn_Find;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lb_Answer;
        private System.Windows.Forms.Button btnClearn;
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}

