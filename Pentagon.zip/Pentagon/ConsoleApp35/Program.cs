﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
    class Program
    {/// <summary>
     /// X2= длина стороны 1-го пятиугольника
     /// </summary>
        int l = 0;
        /// <summary>
        /// Y2= длина стороны 2-го пятиугольника
        /// </summary>
        int k = 0;

        /// <summary>
        /// H2=высота 1-го
        /// </summary>
           int lh = 0;
        /// <summary>
        /// H3=Высота 2-го
        /// </summary>
        int kh =0;

        /// <summary>
        /// pl1= Площадь 1-го
        /// </summary>
        double pl1 = 0;
        /// <summary>
        /// pl2= Площадь 2-го
        /// </summary>
        double pl2 = 0;


        /// <summary>
        /// Экземпляр класса Random
        /// </summary>
        static Random rnd = new Random();
        /// <summary>
        /// Случайными числами заполняем массив
        /// </summary>
        /// <param name="n">Колличество элементов в массиве</param>
        /// <returns>Заполненный массив</returns>
        static Pentagon2D[] RandomPentagon(int n)
        {
            if (n < 0)
                throw new Exception("Количество элементов не может быть отрицательным");
            List<Pentagon2D> mas = new List<Pentagon2D>();
            while (n != 0)
            {
                switch (rnd.Next(2))
                {
                    case 0:
                        {
                             mas.Add(new Pentagon2D(rnd.Next(1, 50)));
                            
                            break;
                        }
                    case 1:
                        {
                            mas.Add(new Pentagon3D(rnd.Next(1, 50), rnd.Next(1, 50))); break;
                        }
                }
                n--;
            }
            return mas.ToArray();
        }

        /// <summary>
        /// Показать всю информацию об правильном пятиугольнике (сторона)
        /// </summary>
        /// <param name="pen">Сам пятиугольник</param>
        //static void AllAboutPentagon(Pentagon2D pen)
        //{
        //    Console.WriteLine("Эта фигура - " + pen.About());
        //    Console.WriteLine("Сторона равна - " + pen.Length);
        //    Console.WriteLine("Площадь этой фигуры - " + pen.Square());
        //    Console.WriteLine("Периметр этой фигуры - " + pen.Perimeter());
        //}
        /// <summary>
        /// Показать всю информацию об правильном пятиугольнике (сторона, высота)
        /// </summary>
        /// <param name="pen">Сам пятиугольник</param>
        //static void AllAboutPentagon3D(Pentagon3D pen)
        //{
        //    Console.WriteLine("Эта фигура - " + pen.About());
        //    Console.WriteLine("Сторона равна - " + pen.Length);
        //    Console.WriteLine("Высота равна - " + pen.Height);
        //    Console.WriteLine("Площадь этой фигуры - " + pen.Square());
        //    Console.WriteLine("Периметр этой фигуры - " + pen.Perimeter());
        //    Console.WriteLine("Объем этой фигуры равен - " + pen.Volume());
        //}

        /// <summary>
        /// Считываем и проверяем вводимый параметр
        /// </summary>
        /// <param name="z"></param>
        /// <returns></returns>
        static int Readd(int z)
        {

            int n = 0;
            do
            {
                Console.WriteLine("Число должно быть больше нуля");
                n = int.Parse(Console.ReadLine());

            }
            while (n == 0 || n < 0);

            return n;
        }
        /// <summary>
        /// Сравнение по площади
        /// </summary>
        /// <param name="x1"></param>
        /// <param name="x2"></param>
        public static void SRAVN(double x1, double x2)
        {
            if (x1 > x2)
                Console.WriteLine(" Первая фигура больше второй");

            if (x1 == x2)
                Console.WriteLine("Первая фигура равна второй");
            if (x1 < x2)
                Console.WriteLine("Первая фигура меньше второй");

        }

        /// <summary>
        /// Сравниваем по Объёму
        /// </summary>
        /// <param name="x1"></param>
        /// <param name="x2"></param>
        public static void SRVN(double x1, double x2)
        {
            if (x1 > x2)
                Console.WriteLine("Объём первой фигуры больше второй");
            if (x1 == x2)
                Console.WriteLine("Объём первой фигуры равна объёма второй");
            if (x1 < x2)
                Console.WriteLine("Объём первой фигуры меньше второй");

        }
       
        static void Main(string[] args)
        {
            try
            {
                int X2 = 0, Y2 = 0, H2 = 0, H3 = 0; // длина стороны высота
                double pl1 = 0;
                double pl2 = 0;////площади
                
                Console.WriteLine("Введите длину  первого правильного пятиугольника ");
                double l = Readd(X2);
                Console.WriteLine("Введите длину  второго правильного пятиугольника ");
                double k = Readd(Y2);

                Pentagon2D X2D = new Pentagon2D();
                pl1 = X2D.Square(l);

                Console.WriteLine("Площадь первой фигуры ");
                Console.WriteLine(pl1);
                Pentagon2D Y2D = new Pentagon2D();
                pl2 = X2D.Square(k);
                Console.WriteLine("Площадь второй фигуры ");
                Console.WriteLine(pl2);


                Console.WriteLine("Периметр первой фигуры = {0}", X2D.Perimeter(l));
                Console.WriteLine("Периметр второй фигуры = {0}", Y2D.Perimeter(k));
                SRAVN(pl1, pl2);
                Console.WriteLine();


                Console.WriteLine("Задание номер 2");

                Console.WriteLine("Введите длину стороны первого правильного пятиугольника ");
                l = Readd(X2);
                Console.WriteLine("Введите длину стороны второго правильного пятиугольника ");
                k = Readd(Y2);

                Console.WriteLine("Введите высоту первого правильного пятиугольника ");
                double lh = Readd(H2);
                Console.WriteLine("Введите высоту второго правильного пятиугольника ");
                double kh = Readd(H3);

                Pentagon3D a = new Pentagon3D(l, lh);
                Pentagon3D b = new Pentagon3D(k, kh);



                Console.WriteLine("Площадь первой фигуры");
                Console.WriteLine(a.Square(l));
                Console.WriteLine("Площадь второй фигуры");
                Console.WriteLine(b.Square(k));

                Console.WriteLine("Периметр первой фигуры");
                Console.WriteLine(a.Perimeter(l));
                Console.WriteLine("Периметр второй фигуры");
                Console.WriteLine(b.Perimeter(k));

                Console.WriteLine("Объём первой фигуры");
                Console.WriteLine(a.Volume(l, lh));

                Console.WriteLine("Объём второй фигуры");
                Console.WriteLine(b.Volume(k, kh));


                SRVN(a.Volume(l, lh), b.Volume(k, kh));
                Console.WriteLine();


                Console.WriteLine("Задание 3");
                Console.WriteLine("Сколько должно быть элементов в массиве?");
                int el = 0;
                int prt=Readd(el);
                Pentagon2D [] mas = RandomPentagon(prt);
                int i = 0;
                foreach (var p in mas)
                {
                    i++;
                    Console.WriteLine();
                    Console.WriteLine("Все о фигуре №" + i);
					//if (p is Pentagon3D)

					//    AllAboutPentagon3D((Pentagon3D)p);

					//else if (p is Pentagon2D)
					//    AllAboutPentagon(p);
					p.About();
                }

                Console.ReadKey();
            }
            

            

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


    }
}