﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
        
        class Pentagon2D 
        {
           

            private double lenght { get; set; }
            /// <summary>
            /// Длина стороны правильного пятиугольника
            /// </summary>
            public double Length
            {
                get { return lenght; }
                set
                {
                    if (value > 0)
                        
                    this.lenght = value;
                }
            }
            /// <summary>
            /// Вызвать конструктор без параметров
            /// </summary>
            public Pentagon2D()
            {

            }
            /// <summary>
            /// Вызвать конструктор
            /// </summary>
            /// <param name="Length">Длина стороны правильного пятиугольника</param>
            public Pentagon2D(double Length)
            {
                this.Length = Length;
            }
        /// <summary>
        /// Метод площади без параметров
        /// </summary>
        /// <returns></returns>

        public  double Square()
        {
            
            return (Math.Pow(Length, 2) * Math.Sqrt(25 + 10 * Math.Sqrt(5))) / 4;
        }
        /// <summary>
        /// Периметр без параметров
        /// </summary>
        /// <returns></returns>
        public  double Perimeter()
        {
           
            return Length * 5;
        }
        /// <summary>
        /// Фигура
        /// </summary>
        /// <returns></returns>
        public virtual void About()
            { 
                Console.WriteLine("Правильный пятиугольник");
				Console.WriteLine("Сторона равна - " + Length);
			Console.WriteLine("Площадь этой фигуры - " + Square());
			Console.WriteLine("Периметр этой фигуры - " + Perimeter());

		}
            /// <summary>
            /// Площадь фигуры с параметром а (сторона)
            /// </summary>
            /// <returns></returns> 
            public  double Square(double a)
            {
            double PL = 0;
            PL = (Math.Pow(a, 2) * Math.Sqrt(25 + 10 * Math.Sqrt(5))) / 4;
            return PL;
               
            }
        /// <summary>
        /// Периметр фигуры с параметром а (сторона)
        /// </summary>
        /// <returns></returns>
        public double Perimeter(double a)
            {
            double PR = 0;
            PR = a * 5;
            return PR;
            }
           
           
            
        }
    }


