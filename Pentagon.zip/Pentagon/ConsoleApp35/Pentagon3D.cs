﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
 
    class Pentagon3D : Pentagon2D
    {

        private double height { get; set; }
        
        /// <summary>
        /// Высота правильного пятиугольника
        /// </summary>
        public double Height
        {
            get { return height; }
            set
            {
                if (value > 0)
                    
                this.height = value;
            }
        }
      
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="Length">Длина пятиугольника</param>
        /// <param name="Height">Высота пятиугольника</param>
        public Pentagon3D(double Length, double Height) : base(Length)
        {
            //this.Length = Length;
            this.Height = Height;
        }
        /// <summary>
        /// Показать тип фигуры
        /// </summary>
        /// <returns></returns>
        public override void About()
        {
            Console.WriteLine("Правильный пятиугольник с высотой");
			Console.WriteLine("Сторона равна - " + Length);
			Console.WriteLine("Высота равна - " + Height);
			Console.WriteLine("Площадь этой фигуры - " + Square());
			Console.WriteLine("Периметр этой фигуры - " + Perimeter());
			Console.WriteLine("Объем этой фигуры равен - " + Volume());
		}
        /// <summary>
        ///  Периметр фигуры с параметром (сторона)
        /// </summary>
        /// <returns></returns>
        public  double Perimeter(int a)
        {
            int Pr = 0;
            Pr = a * 5;
            return Pr;
        }
        /// <summary>
        /// Площадь фигуры с параметром (сторона)
        /// </summary>
        /// <returns></returns>
        public new double Square(double a)
        {
            double SL = 0;
           SL= base.Square(a);
            return SL;
        }

        /// <summary>
        /// Конструктор без параметров
        /// </summary>
        public Pentagon3D()
        {

        }
        /// <summary>
        /// Объём фигуры с параметрами (сторона, высота)
        /// </summary>
        /// <returns></returns>
        public  double Volume(double a, double h)
        {
            
            return Square(a) * h;
        }
        /// <summary>
        /// Объём фигуры без параметров
        /// </summary>
        /// <returns></returns>
        public  double Volume()
        {

            return base.Square() * height;
        }


    }
}


   
