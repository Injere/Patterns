def getChr(i):
    return chr(i + 97)

def genRK(n):
    print("# fourth order Runge-Kutta method in " + str(n) + " dimensions")
    u = ""
    v = ""
    f = ""
    for i in range(n):
        c = getChr(i)
        if i != 0:
            u += ", "
            v += ", "
            f += ", "
        u += c
        v += c + "k"
        f += "f" + c
    print("def rK" + str(n) + "(" + u + ", " + f + ", hs" + "):")
    for i in range(n):
        c = getChr(i)
        print("\t" + c + "1 = f" + c + "(" + u + ")*hs")
    for i in range(n):
        c = getChr(i)
        print("\t" + c + "k = " + c + " + " + c + "1*0.5")
    for i in range(n):
        c = getChr(i)
        print("\t" + c + "2 = f" + c + "(" + v + ")*hs")
    for i in range(n):
        c = getChr(i)
        print("\t" + c + "k = " + c + " + " + c + "2*0.5")
    for i in range(n):
        c = getChr(i)
        print("\t" + c + "3 = f" + c + "(" + v + ")*hs")
    for i in range(n):
        c = getChr(i)
        print("\t" + c + "k = " + c + " + " + c + "3")
    for i in range(n):
        c = getChr(i)
        print("\t" + c + "4 = f" + c + "(" + v + ")*hs")
    for i in range(n):
        c = getChr(i)
        print("\t" + c + " = " + c + " + (" + c + "1 + 2*(" + c + "2 + " + c + "3) + " + c + "4)/6")
    print("\treturn " + u)

genRK(4)
