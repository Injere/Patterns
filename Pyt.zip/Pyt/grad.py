# для нахождения производной
from scipy.misc import derivative

# для работы графиков
import matplotlib.pyplot as plt

# определяем функцию
def f(x):
    return (x-5)**2

# проверяем нахождение f'(x)
derivative(f, 0)

# рисуем график функции
x = range(-5,15)
y = [f(xn) for xn in x]
plt.plot(x, y)
plt.show()

# подготовка к Град. спуску

# начальн. значение
xn = 0 
yn = f(xn)

# заводим словарь, где будем хранить все найденные значения функции
Y = {xn: yn}

# шаг ГС (произвольный подибраем)
step = 0.1

# по формуле градиентного спуска получаем все значения x y
for _ in range(25):
    xn = xn - step*derivative(f, xn)
    yn = f(xn)
    Y[xn] = yn

Y

# наносим найденные точки на график
plt.plot(list(Y.keys()), list(Y.values()), 'ro')
plt.show()

# масштабируем
plt.plot(list(Y.keys()), list(Y.values()), 'ro')
plt.axis([4.95, 5.05, -0.05, 0.05])
plt.show()

# словарь значений, где key = х (просто инвертируем Y)
X = {}
for i in range(len(Y)):
    X[list(Y.values())[i]] = list(Y.keys())[i]

# выводим пару искомых минимальных X и Y (близких к минимумам)
print ('мин. Х =', min(X.items())[1])
print ('мин. Y =', min(X.items())[0])
