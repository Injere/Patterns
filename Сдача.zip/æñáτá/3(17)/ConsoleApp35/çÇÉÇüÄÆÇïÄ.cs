﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;  int R; int n; int cher=0;
            Go go = new Go();
            Go finished = new Go();
            Go Last = new Go();
            do
            {
                Console.WriteLine("Введите количество элементов");
            }
            while (!int.TryParse(Console.ReadLine(), out n));


            Random random = new Random();
            for (int i=0;i<n;i++) //запускаем цикл на заполнение очереди
            {
                go.AddInEnd(a = random.Next(-15, 15));
                if (a % 2 == 0)
                {
                    cher++;
                }
            }
            Console.WriteLine("Начальный стек");
            go.Output();//вывод
                        //Console.WriteLine(cher);

            int cr = cher;

            for (int i = 0; i < n; i++)
            {
                R = go.DelEnd();
                if (R % 2 == 0)
                {
                    Last.AddInEnd(R);
                }
                else
                {
                    finished.AddInEnd(R);
                }
                
            }
            Console.WriteLine("Стек с чётными числами");
            Last.Output();
            Console.WriteLine("Стек с нечётными числами");
            finished.Output();

            //for (int j=0;j<1;j++)
            //{
                for(int r=0;r<cher;r++)
                {
                    R=Last.DelEnd();
                    go.AddInEnd(R);

                }
                for (int r = 0; r < n-cr; r++)
                {
                    R = finished.DelEnd();
                    go.AddInEnd(R);

                }
            //}

            Console.WriteLine("Готовый стек");

            go.Output();

        }
    }
}
