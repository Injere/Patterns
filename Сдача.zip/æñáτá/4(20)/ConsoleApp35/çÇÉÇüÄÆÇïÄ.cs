﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
    class Program
    {

        /// <summary>
        /// Дана очередь из целых чисел. Поместить в начало очереди сумму модулей всех элементов.
        /// </summary>
        /// <param name="args"></param>
        /// 




        static void Main(string[] args)
        {
            int a; int n; 
            Go go = new Go();
            Go jk = new Go();
            Go New = new Go();
            Go finished = new Go();
            do
            {
                Console.WriteLine("Введите количество элементов");
            }
            while (!int.TryParse(Console.ReadLine(), out n));


            Random random = new Random();
            for (int i = 0; i < n; i++) //запускаем цикл на заполнение очереди
            {
                go.AddInEnd(a = random.Next(-15, 6));
            }
            Console.WriteLine("Начальная очередь");
            go.Output();//вывод

            int A; int B;  int L; L = go.length();


            
            for(int i=0;i<L;i++)
            {
                A = go.DelBegin();
                for(int j=0;j<L-1;j++)
                {
                    B = go.DelBegin();
                    if(A!=B)
                    {
                        go.AddInEnd(B);
                    }
                    //go.Output();

                }
                go.AddInEnd(A);
                L = go.length();
            }

            go.Output();
           

        }
    }
}
