﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
    class Program
    {
        
        /// <summary>
        /// Дана очередь из целых чисел. Поместить в начало очереди сумму модулей всех элементов.
        /// </summary>
        /// <param name="args"></param>
        /// 

        static void Main(string[] args)
        {
            int a; int R=0; int n; int A;
            Go go = new Go();
            Go jk = new Go();
            Go finished = new Go();
            do
            {
                Console.WriteLine("Введите количество элементов");
            }
            while (!int.TryParse(Console.ReadLine(), out n));


            Random random = new Random();
            for (int i=0;i<n;i++) //запускаем цикл на заполнение очереди
            {
                go.AddInEnd(a = random.Next(-15, 15));
            }
            Console.WriteLine("Начальная очередь");
            go.Output();//вывод



            for (int i=0;i<n;i++)
            {
                A = go.DelBegin();
                finished.AddInEnd(A);


                R += Math.Abs(A);
                //jk.AddInEnd(R);

            }
            Console.WriteLine("Промежуточная очередь (копия)");
            finished.Output();

            Console.WriteLine("сумма модулей всех элементов");
            Console.WriteLine(R);

           
             go.AddInEnd(R);

            
            for (int r = 0; r < n; r++)
            {
                R = finished.DelBegin();
                go.AddInEnd(R);

            }
            Console.WriteLine("Готовая очередь");
            go.Output();
            

        }
    }
}
