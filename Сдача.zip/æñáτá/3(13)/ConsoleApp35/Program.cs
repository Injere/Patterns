﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            Go go = new Go();
            Random random = new Random();
            for (int i=0;i<5;i++)
            {
                go.AddInBegin(a = random.Next(-15, 15));
            }
            go.Output();
        }
    }
}
