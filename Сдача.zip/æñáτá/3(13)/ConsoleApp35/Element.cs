﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
    class Element
    {
        
        public int tail { get; set; }
        public Element NextEL { get; set; }
        
        public Element(int inf)//вызвался конструктор класса
        {
            tail = inf;//
            NextEL = null;
        }
            

    }

}
