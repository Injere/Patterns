﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
    class Program
    {
        static void Main(string[] args)
        {
            int a; int minus; int R; int n;
            Go go = new Go();
            Go jk = new Go();
            Go finished = new Go();
            do
            {
                Console.WriteLine("Введите количество элементов");
            }
            while (!int.TryParse(Console.ReadLine(), out n));


            Random random = new Random();
            for (int i=0;i<n;i++) //запускаем цикл на заполнение очереди
            {
                go.AddInEnd(a = random.Next(-15, 15));
            }
            go.Output();//вывод


            do
            {
                Console.WriteLine("Введите число, которое хотите отнять");
            }
            while (!int.TryParse(Console.ReadLine(), out minus));

            for (int i=0;i<n;i++)
            {
                R = go.DelEnd();
                jk.AddInEnd(R - minus);
            }
            
            for(int i=0; i<n;i++)
            {
                R = jk.DelEnd();
                finished.AddInEnd(R);
            }
            finished.Output();

        }
    }
}
