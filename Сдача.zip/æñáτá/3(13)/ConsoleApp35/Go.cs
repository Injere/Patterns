﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
    class Go
    {
        Element Head = null;//даём значение null ссылке на голову
        int col = -1;//


        public void AddInBegin(int a)
        {
            Element NewNode = new Element(a);//создаём экземпляр класса Element
            NewNode.NextEL = Head;
            Head = NewNode;//присваиваем ссылку на новое значение
            col++;
        }

        public void AddInEnd(int a)
        {
            Element NewNode = new Element(a);//создаём элемент класса Go
            if (Head == null)//проверка на пустоту
                AddInBegin(a);
            else
            {
                Element p = Head;
                while (p.NextEL != null)
                    p = p.NextEL;
                p.NextEL = NewNode;
            }
            col++;
        }

        public void Output()
        {
            Console.WriteLine();
            Element p = Head;
            while (p != null)
            {
                Console.Write(p.tail + "\t");
                p = p.NextEL;
            }
            Console.WriteLine();
        }
        public int DelBegin()
        {
            if (Head != null)
            {
                int n = Head.tail;
                Head = Head.NextEL;
                col--;
                return n;
            }
            else
                throw new Exception("Пустая очередь");
        }

        public int DelEnd()
        {
            if (Head != null)
            {
                if (Head.NextEL != null)
                {
                    Element p = Head;
                    while (p.NextEL.NextEL != null)
                        p = p.NextEL;
                    int n = p.NextEL.tail;
                    p.NextEL = null;
                    return n;
                }
                else
                {
                    int n = Head.tail;
                    Head = null;
                    col--;
                    return n;
                }
            }
            else
                throw new Exception("Пустая очередь");
        }

        public int length()
        {
            return col;
        }

        public int Inf(int n)
        {
            Element p = Head;
            for (int i = 0; i < n; i++)
            {
                p = p.NextEL;
            }
            return p.tail;
        }

    }       

}
    



