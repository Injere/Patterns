﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp37
{
    class Program

    {
        /// <summary>
        /// Вывод
        /// </summary>
        /// <param name="A"></param>
        static void Output(int[] A)
        {

            for (int i = 0; i < A.Length; i++)
                Console.Write(A[i] + " ");
            Console.ReadKey();

        }
        /// <summary>
        /// Проверка значения
        /// </summary>
        /// <returns></returns>
        public static int Control()
        {
            int s = -1;
            do
            {
                Console.WriteLine("введите целое число");
            }
            while ((!int.TryParse(Console.ReadLine(), out s)) || s <= 0);
            return s;
        }

       


        /// <summary>
        /// Заполнение массива
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        public static int[] Input(int n)
        {
            int[] A = new int[n];
            Random random = new Random();
            for (int i = 0; i < n; i++)
            {
                A[i] = random.Next(1, 150000);

            }
            return A;
        }
        /// <summary>
        /// Линейный поиск
        /// </summary>
        /// <param name="L"></param>
        public static void Line(int[] L)
        {
            int D; int count = 0;
            int[] PoL = new int[0];
            Console.WriteLine("Введите элемент поиска");
            {
                D = Control();
                for (int i = 0; i < L.Length; i++)
                {
                    if (L[i] == D)
                    {
                        count++;
                    }

                }
            }
            if (count != 0)
            {
                Console.WriteLine("Количество найденный элементов: {0}", count);
            }
            else
            {
                Console.WriteLine("элементы не найдены");
            }
        }

        /// <summary>
        /// Сортировка методом Шелла
        /// </summary>
        /// <param name="A"></param>
        /// <param name="Time"></param>
        static void ShellSort(int[] A, ref int Time)
        {
            int start = Environment.TickCount;
            int k;
            int step = A.Length / 2;
            while (step > 0)
            {
                for (int i = 0; i < (A.Length - step); i++)
                {
                    k = i;
                    while ((k >= 0) && (A[k] > A[k + step]))
                    {
                        int tmp = A[k];
                        A[k] = A[k + step];
                        A[k + step] = tmp;
                        k -= step; //идём дальше
                    }
                }
                step = step / 2;
            }
            Time = Environment.TickCount - start;
        }

        /// <summary>
        /// Интерполяционный поиск
        /// </summary>
        /// <param name="list"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public static int Search(int[] list, int data)
        {
            int lo = 0;
            int mid = -1;
            int hi = list.Length - 1;
            int index = -1;
            int count = 0;
            int RT = 0;

            while (lo <= hi)
            {
                mid = (int)(lo + (((double)(data - list[lo]) / (hi - lo)) * (list[hi] - list[lo])));
                if (list[mid] == data)
                {
                    index = mid;
                    count++;
                   
                    break;
                }
                else
                {
                    if (list[mid] < data)
                        lo = mid + 1;
                    else
                        hi = mid - 1;
                }
            }
           
                return index;
            
            
           
        }


        /// <summary>
        /// Начало работы 
        /// </summary>
        /// <param name="args"></param>

        static void Main(string[] args)

        {

            int[] sw = new int[0];
            int[] klew = new int[0];
            int[] shell = new int[0];

            // создать объект пользовательского класса

            ConsoleKeyInfo K;

            do

            {

                Console.Clear(); //очистка экрана перед выводом меню

                Console.WriteLine("Генерация массива");

                Console.WriteLine("Интерполяционный поиск");

                Console.WriteLine("Линейный поиск");

                Console.WriteLine("Показать текущий массив");


                K = Console.ReadKey(); //считывание кода вводимой клавиши

                switch (K.Key)

                {

                    case ConsoleKey.D1: // если нажата клавиша с цифрой 1

                        {
                            Console.Clear();
                            Console.WriteLine("Генерация массива");
                            {
                                Console.WriteLine("Укажите количество элементов");



                                int fe = Control();


                                int[] arr1 = Input(fe);
                                Array.Resize(ref sw, fe);
                                Array.Resize(ref klew, fe);
                                Array.Resize(ref shell, fe);

                                Array.Copy(arr1, sw, fe);
                                Array.Copy(arr1, klew, fe);
                                Array.Copy(arr1, shell, fe);

                                Output(arr1);


                            }

                            break;

                        }

                    case ConsoleKey.D2: // если нажата клавиша с цифрой 2

                        {
                            Console.Clear();
                            Console.WriteLine("Интерполяционный поиск");
                            Console.WriteLine("Внимание! Интерполяционный поиск выдаёт только ИНДЕКС первого вхождения!!! \n В остортированном массиве ");
                            int Time = 0;
                            //int start = Environment.TickCount;
                           
                            ShellSort(sw,ref Time);
                            Console.WriteLine("Введите элемент поиска");




                            int ss =Control();
                            Time = 0;
                            int start = Environment.TickCount;

                            int R=(Search(sw,ss));
                            Time = Environment.TickCount - start;
                           
                                Console.WriteLine($"\nВремя поиска {Time} mc");

                                Console.WriteLine($"\nИндекс ключевого элемента {R}");
                           

                           
                            //Output(sw);
                            
                            Console.Write("Для продолжения нажмите Enter");
                            Console.ReadKey();

                            break;

                        }


                    case ConsoleKey.D3: // если нажата клавиша с цифрой 1

                        {
                            Console.Clear();

                            {

                                Console.WriteLine("Линейный поиск: ");

                                int Time = 0;
                                ShellSort(shell, ref Time);
                                Line(shell);

                                //Output(shell);
                                Console.WriteLine($"\nВремя сортировки {Time} mc");
                                Console.Write("Для продолжения нажмите Enter");
                                Console.ReadLine();
                                Console.Clear();


                            }




                            break;

                        }


                    case ConsoleKey.D4: // если нажата клавиша с цифрой 4

                        {
                            Console.Clear();
                            Console.WriteLine("Показать текущий массив:");
                            if (klew.Length == 0)
                            {
                                Console.WriteLine("Массив не создан");
                                Console.ReadKey();
                            }
                            else
                                Output(klew);
                            Console.ReadKey();

                            break;

                        }


                    default: break;

                }

                // приостанавливаем выполнение текущего потока на заданное число времени. Время измеряется в миллисекундах

                //System.Threading.Thread.Sleep(2000); // 2 сек.

            }

            while (K.Key != ConsoleKey.Escape);// цикл заканчивается, если нажата клавиша Esc
        }

    }
}
