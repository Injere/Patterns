﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp35
{
    class Program
    {
        
        /// <summary>
        /// Дана очередь из целых чисел. Поместить в начало очереди сумму модулей всех элементов.
        /// </summary>
        /// <param name="args"></param>
        /// 

        static void Main(string[] args)
        {
            int a; int R=0; int n; int A; int o; bool tr=false;
            Go go = new Go();
            Go jk = new Go();
            Go finished = new Go();
            do
            {
                Console.WriteLine("Введите количество элементов");
            }
            while (!int.TryParse(Console.ReadLine(), out n));


            Random random = new Random();
            for (int i=0;i<n;i++) //запускаем цикл на заполнение очереди
            {
                go.AddInEnd(a = random.Next(-15, 15));
            }
            Console.WriteLine("Начальная очередь");
            go.Output();//вывод



           

            do
            {
                Console.WriteLine("Введите число");
            }
            while (!int.TryParse(Console.ReadLine(), out o));



            int s;
            for(int i=0;i<n;i++)
            {
                while (tr == false)
                {

                     s = go.DelBegin();
                    if (s == o && go.length() == n - 1)
                    {
                        Console.WriteLine("Дейтсвие невозможно!");
                        break;
                    }
                    else
                    {

                        finished.AddInEnd(s);
                        if (s == o)
                        {
                            
                            tr = true;
                        }
                    }
                }
              

            }




            if(tr==true)
            {
                int Reg = finished.DelEnd();
                int Reg1 = finished.DelEnd();
                int Reg2 = finished.DelEnd();
                finished.AddInEnd(Reg2);
                finished.AddInEnd(Reg2 * o);
                finished.AddInEnd(Reg1);
                finished.AddInEnd(Reg);
                tr = false;
            }
            n = go.length();

            for(int i = 0; i < n; i++)
            {
                finished.AddInEnd(go.DelBegin());
            }


            finished.Output();
            Console.WriteLine();
            
            

          

            
           

        }
    }
}
